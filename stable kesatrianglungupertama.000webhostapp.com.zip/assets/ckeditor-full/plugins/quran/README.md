# Quran plugin for ckeditor

###Development quickstart :
Install Yeoman

Clone this repo : https://github.com/tasfya/quran_ckeditor_webapp

Run : bower install && npm install

cd into : bower_components/ckeditor/plugins/

run git clone https://github.com/tasfya/quran_ckeditor quran

Run grunt serve and You're Done
