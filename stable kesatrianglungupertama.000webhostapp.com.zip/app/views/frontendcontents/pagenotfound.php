<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
	<!--==============================content================================-->
	<section id="content">
		<div class="main">
			<div class="container_12">
				<div class="wrapper">
					<article class="grid_8">
						<h1>Page Not Found</h1>
					</article>
				</div>
			</div>
		</div>
	</section>