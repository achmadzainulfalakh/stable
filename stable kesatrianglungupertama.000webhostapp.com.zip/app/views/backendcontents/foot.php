    

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url()."assets/admin" ?>/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo base_url()."assets/admin" ?>/bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="<?php echo base_url()."assets/admin" ?>/dist/js/sb-admin-2.js"></script>
	
	<!-- custom jquery -->
	<script type="text/javascript" src="<?php print base_url()."assets/js/custom_jquery.js" ?>"></script>
	
	<!-- Morris Charts JavaScript -->
    <script src="//localhost/cdn/js/raphael-min.js"></script>
    <script src="//localhost/cdn/js/morris.min.js"></script>
    <script src="<?php print base_url()."assets/js/morris-data.js" ?>"></script>

</body>

</html>