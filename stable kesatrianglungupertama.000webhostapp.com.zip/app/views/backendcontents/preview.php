<div class="container">
	

			<div class="row">
				<div class="col-sm-12 col-lg-12">
					<h3><?php print $posts->post_title ?></h3>
				</div>
			</div>
				<?php print $posts->post_content ?>


</div>