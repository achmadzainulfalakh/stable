<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
    <!-- jQuery -->
    <!--<script src="http://cdn.achmad.me/js/jquery.js" ></script>-->
	<!-- custom jQuery code -->
	<script src="<?php echo  $this->config->item('assets'); ?>js/custom_jquery.js" ></script>

    <!-- Bootstrap Core JavaScript -->
    <!--<script src="<?php //echo  $this->config->item('cdn'); ?>js/bootstrap.min.js" ></script>-->

    <!-- Custom Theme JavaScript -->
    <!--<script src="http://cdn.achmad.me/js/clean-blog.min.js" ></script>-->

</body>

</html>