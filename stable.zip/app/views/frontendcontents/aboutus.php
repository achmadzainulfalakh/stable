<?php 
$arr=array('post_name'=>'about');
$posts=$this->posts_model->get_post_by($arr); 
?>
<!--=====================
          Content
======================-->
<section id="content" class="line-bottom">
  <div class="container landing-container" id="About" style="padding-top:80px">
    <div class="row" >
		<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
			<h3><?php print $posts->post_title ?></h3>
		</div>
	</div>
	<br/>
		<?php print $posts->post_content ?>
	
    </div>
 <br/>
</section>
<?php
//Backup content don't remove
/*

<section id="content" class="line-bottom">
  <div class="container landing-container" id="About" style="padding-top:80px">
    <div class="row" >
		<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
			<h3>About Us</h3>
		</div>
	</div>
	<br/>
	<div class="row" style="padding-bottom:20px">
		
		  <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
			<center><img src="<?php echo base_url().'assets\images\page2_img1.jpg' ?>" alt="About img" class="img-responsive img-thumbnail"></center>
		  </div>
		  <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
			<p class="fwn" ><a href="#">SARANA LINTAS DATA merupakan badan usaha yang bergerak dalam bisnis Telekomunikasi, Informatika, Web Developer dan Software Developer.</a></p>
			<p>SARANA LINTAS DATA didukung oleh para profesional muda yang berpengalaman dibidangnya dan sangat berkompeten. </p>
		  </div>
		  <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
			<p  >Dengan tenaga kerja yang sangat mumpuni ini kami menyediakan layanan Tecnical Support selama 6 hari. Hal ini semata-mata karena untuk memenuhi komitmen kami untuk selalu mengedepankan kualitas produk dan layanan guna menjaga dan memelihara kepercayaan konsumen atas kinerja kami.</p>
		  </div>
	</div>
	
	<div class="row" >	
		<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
			<p>Sejak awal didirikannya pada tanggal 28 Desember 2014 hingga saat ini, SARANA LINTAS DATA telah mengalami berbagai transformasi. Transformasi dari usaha kecil untuk mereparasi hardware personal computer, tumbuh hingga menjadi usaha solusi teknologi jaringan dan multimedia untuk kepentingan entertaiment hingga akhirnya berkembang hingga saat ini menjadi usaha telekomunikasi, informatika, web developer dan software developer dengan sumberdaya manusia yang mampu menjawab tantangan dunia ICT yang semakin ketat persaingannya.</p>
		</div>
	</div>
    </div>
 <br/>
</section> 

*/
?>
