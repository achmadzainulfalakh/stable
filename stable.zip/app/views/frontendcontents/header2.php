<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>
<!--==============================
              header
=================================-->
<header >
  <div class="container">
    <div class="row">
      <div class="grid_12 rel">
        <h1>
          <a href="<?php echo base_url() ?>">
            <img src="<?php echo base_url() ?>assets/images/logo.png" alt="Logo alt">
          </a>
        </h1>
      </div>
    </div>
  </div>
  <section id="stuck_container" >
