<div class="block-1">
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-3 col-md-3 col-lg-3">
        <div class="block-1_count"><?php echo $this->settings_model->get_options('numheader1') //mendapatkan selogan situs ?></div>
        <?php echo $this->settings_model->get_options('textheader1') //mendapatkan selogan situs ?>
        <div class="clear"></div>
      </div>
      <div class="col-xs-12 col-sm-3 col-md-3 col-lg-3">
        <div class="block-1_count"><?php echo $this->settings_model->get_options('numheader2') //mendapatkan selogan situs ?></div>
        <?php echo $this->settings_model->get_options('textheader1') //mendapatkan selogan situs ?>
        <div class="clear"></div>
      </div>
      <div class="col-xs-12 col-sm-3 col-md-3 col-lg-3">
        <div class="block-1_count"><?php echo $this->settings_model->get_options('numheader3') //mendapatkan selogan situs ?></div>
        <?php echo $this->settings_model->get_options('textheader1') //mendapatkan selogan situs ?>
        <div class="clear"></div>
      </div>
      <div class="col-xs-12 col-sm-3 col-md-3 col-lg-3">
        <a href="#Contact-Us" class="support"><img src="<?php echo base_url() ?>assets/images/support.png" alt=""></a>
      </div>
    </div>
  </div>
</div>