        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Pages</h1>
						

						<div class="col-lg-12">
							<div class="panel panel-default">
								
								<div class="panel-heading">
									<h3>Form edit</h3>
								</div>
								<!-- /.panel-heading -->
								<div class="panel-body">
									<form role="form">
										<div class="form-group">
											<label>Link</label>
											<input class="form-control" readonly>
										</div>
										<div class="form-group">
                                            <label>Status</label>
                                            <label class="radio-inline">
                                                <input type="radio" name="optionsRadiosInline" id="optionsRadiosInline1" value="option1" checked>Publish
                                            </label>
                                            <label class="radio-inline">
                                                <input type="radio" name="optionsRadiosInline" id="optionsRadiosInline2" value="option2">Draft
                                            </label>
                                        </div>
										<div class="form-group">
											<label>Order</label>
											<input class="form-control">
											<p class="help-block">Valid: text validasi</p>
										</div>
										
										<div class="form-group">
											<label>Name</label>
											<input class="form-control">
											<p class="help-block">Valid: text validasi</p>
										</div>
										
										<div class="form-group">
                                            <label>Content</label>
                                            <textarea class="form-control ckeditor" id="ckedtor" rows="3"></textarea>
                                        </div>
										
										
									<button type="submit" class="btn btn-default btn-lg col-lg-12"> Simpan </button>
									<!--<button type="reset" class="btn btn-default">Reset</button>-->
									</form>
								</div>
								<!-- /.panel-body -->
								
							</div>
							<!-- /.panel -->
						</div>
						<!-- /.col-lg-12 -->

						
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->




