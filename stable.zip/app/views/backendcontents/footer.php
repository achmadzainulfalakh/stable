		<!-- /#ajax layout -->
		</div>
	</div>
    <!-- /#wrapper -->

<div class="container-fluid">
	<div class="row">
		<div class="col-lg-12">
			<hr>
			<p><?=$this->settings_model->get_copyr() ?></p>
		</div>
		<!-- /.col-lg-12 -->
	</div>
	<!-- /.row -->
</div>
