        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Message</h1>
		
						

						<div class="jumbotron">

						

							<h3><?php print $data->message ?></h3>


							<hr />

							<div class="row">
								<div class="col-sm-6">
									<h5>Sender: <?php print $data->name ?></h5>

									<h5>Email: <?php print $data->email ?></h5>
								</div>
								<div class="col-sm-6">
									<h5>Time: <?php print $data->date ?></h5>
								</div>
							</div>
						

						
						</div>

						

						

											
						
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->




